<?php
$api_guest='api_guest';
$api_guest_key='api_guest_key';

$api_user='api_user';
$api_user_key='api_user_key';

$api_oper='api_oper';
$api_oper_key='api_oper_key';

$api_super='api_super';
$api_super_key='api_super_key';

