<?php
// Заглушка
function mysql_escape($str)
{
 return $str;
}
function mysql_execute($query)
{
 return true;
}
