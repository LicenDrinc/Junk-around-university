<?php

# чтение файла и перевод в base64, без сохранение файла в памяти
function base64_encode_stream($path)
{
    $fp = fopen($path, 'rb');
    $result = ''; $bufferSize = 1024 * 3;
    while (!feof($fp)) {
        $chunk = fread($fp, $bufferSize);
        if ($chunk === false) break;
        $result .= base64_encode($chunk);
        unset($chunk);
    }
    fclose($fp); return $result;
}

# прикрощение работы и отправки ошибки: $n информация об ошибке, $b номер ошибки
function exitError($n, $b) { global $execlog; $res['errors'] = $n; $res['error'] = $b; /*$res["log"] = $execlog;*/ return api_json_result($res); }

# создание временного файл: $n название файла, $d данные файла, возращает путь к файлу
function createTmpFile($n, $d) { $n = '/tmp/'.md5(time().rand()).$n; file_put_contents($n, base64_decode($d)); return $n; }

# праверка входящих файлов: $n массив из типо файлов
function checkSeveralFromFile($n) {
    global $filename, $typeconvert;
    if (count($filename) < 1) return exitError("не было переданы входящие файлы", 101);
    for ($i = 0; $i < count($filename); $i++) {
        $fileformat = substr($filename[$i],strrpos($filename[$i],'.')+1);
        if (!in_array($fileformat, $n)) return exitError("неправильный тип входящего файла под названием ".$filename[$i]." для правила ".$typeconvert, 102);
    }
    return 0;
}

# праверка входящего файла: $n массив из типо файлов
function checkOneFromFile($n) {
    global $filename, $typeconvert;
    if (count($filename) < 1) return exitError("не было переданы входящий файл", 103);
    if (count($filename) > 1) return exitError("передано несколько входящих файлов, а требуется один", 104);
    $fileformat = substr($filename[0],strrpos($filename[0],'.')+1);
    if (!in_array($fileformat, $n)) return exitError("неправильный тип входящего файла под названием ".$filename[0]." для правила ".$typeconvert, 105);
    return 0;
}

# праверка выходящего файла: $n массив из типо файлов
function checkOneInFile($n) {
    global $fileout, $typeconvert, $fileformat;
    if ($fileout == null) return exitError("не было переданы название выходящего файла", 106);
    //if (count($fileout) > 1) return exitError("передано несколько выходящих файлов, а требуется один", 107);
    $fileformat = substr($fileout,strrpos($fileout,'.')+1);
    if (!in_array($fileformat, $n)) 
        return exitError("неправильный тип выходящего файла под названием ".$fileout." для правила ".$typeconvert, 108);
    return 0;
}

# создание временных файлов
function createSeveralTmpFile() {
    global $filenamelist, $filenametmp, $filename, $file; $filenamelist = '';
    for ($i = 0; $i < count($filename); $i++) {
        $filenametmp[$i] = createTmpFile($filename[$i], $file[$filename[$i]]);
        chmod($filenametmp[$i], 0777);
        $filenamelist .= '"'.$filenametmp[$i].'" '; # добавление в список файлов для конвертации
        if (!file_exists($filenametmp[$i])) { # проверка временого файла
	        for ($j = 0; $j < $i; $j++) unlink($filenametmp[$j]);
	        return exitError("создание временного файла под названием ".$filename[$i]." не прошла успешно", 109);
        }
    }
    return 0;
}

# создание временого файла
function createOneTmpFile() {
    global $filenamelist, $filenametmp, $filename, $file;
    $filenametmp[0] = createTmpFile($filename[0], $file[$filename[0]]);
    chmod($filenametmp[0], 0777);
    $filenamelist = '"'.$filenametmp[0].'" '; # добавление в список файлов для конвертации
    # проверка временого файла
    if (!file_exists($filenametmp[0])) return exitError("создание временного файла под названием ".$filename[0]." не прошла успешно", 110);
    return 0;
}

# создание пути одного сконвертированого файла
function createOneConvFile() { global $filenewnametmp, $fileout; $filenewnametmp = "/tmp/".md5(time().rand()).$fileout; }

# обработка входящих параметров. Для правил: ImageToImage, ImageToPDF, ImageToGIF
function paraForConvImage() {
    global $parametrs, $imagetopara, $imageparaname; $parametrs = '';
    for ($i = 0; $i < count($imageparaname); $i++) {
        $reqpara = api_check_request($imageparaname[$i]);
        if ($reqpara !== false) $parametrs .= $imagetopara[$imageparaname[$i]].' '.$reqpara.' ';
    }
}

# обработка входящих параметров. Для правил: WriterToPdf
function paraForConvLibre() {
    global $parametrs, $libretopara, $libreparaname; $parametrs = '';
    for ($i = 0; $i < count($libreparaname); $i++) {
        $reqpara = api_check_request($libreparaname[$i]);
        if ($reqpara !== false) $parametrs .= $libretopara[$libreparaname[$i]].' '.$reqpara.' ';
    }
}

# конвертация для правил: ImageToImage, ImageToPDF, ImageToGif
function convImage() {
    global $execlog, $filenamelist, $parametrs, $filenewnametmp;
    $execlog = "convert " . exec('convert '.$filenamelist.$parametrs.'"'.$filenewnametmp.'"');
}

# конвертация для правил: WriterToPdf
function convLibre($n) {
    global $execlog, $filenamelist, $parametrs, $filenewnametmp, $dirnewnametmp, $fileformat, $filenametmp;
    $tmp = '/libre/'.md5(time().rand());
    exec('export HOME=/tmp'.$tmp.' && '.
        'libreoffice --headless --convert-to "'.$fileformat.':'.$n.'" '.$filenamelist.
        '--outdir '.$dirnewnametmp.' 2>&1' , $execlog["libre out"], $execlog["libre code"]);
    $execlog["libre cmd"] = 'export HOME=/tmp'.$tmp.' && '.
        'libreoffice --headless --convert-to "'.$fileformat.':'.$n.'" '.$filenamelist.
        '--outdir '.$dirnewnametmp.' 2>&1';
    $f = $dirnewnametmp.'/'.substr($filenametmp[0],strrpos($filenametmp[0],'/')+1);
    $f1 = substr($f,0,strrpos($f,'.')).'.'.$fileformat;
    exec('mv "'.$f1.'" "'.$filenewnametmp.'"');
    $execlog["mv cmd"] = 'mv "'.$f1.'" "'.$filenewnametmp.'"';
    exec("rm -r /tmp".$tmp);
}

# удаление временого файла
function deleteOneTmpFile() { global $filenametmp; unlink($filenametmp[0]); }

# удаление временых файлов
function deleteSeveralTmpFile() { global $filenametmp; for ($i = 0; $i < count($filenametmp); $i++) unlink($filenametmp[$i]); }

# проверка и отправка одного сконвертированого файла
function pushOneNewFile() {
    global $filenewnametmp, $fileout;
    # проверка сканвертированого
    if (!file_exists($filenewnametmp)) return exitError("конвертация не прошла успешно", 111);
    //$res['file'] = base64_encode(file_get_contents($filenewnametmp)); # полученое содержимого сконвертированого файла
    $res['file'] = base64_encode_stream($filenewnametmp); # полученое содержимого сконвертированого файла
    unlink($filenewnametmp); # удаление сконвертированого временого файла
    # все норм, утверждаем это
    $res['errors'] = ""; $res['error'] = 0; $res['filename'] = $fileout;
    return api_json_result($res);
}

# функции для работы с утилитами и одни или несколькоми файлами на входе и навыходе: <один, несколько><утилита>To<один, несколько>
function SeveralImageToOne($n, $h) {
    $error = checkSeveralFromFile($n);
    if ($error !== 0) return $error;
    $error = checkOneInFile($h);
    if ($error !== 0) return $error;
    $error = createSeveralTmpFile();
    if ($error !== 0) return $error;
    createOneConvFile();
    paraForConvImage();
    convImage();
    deleteSeveralTmpFile();
    return pushOneNewFile();
}

function OneImageToOne($n, $h) {
    $error = checkSeveralFromFile($n);
    if ($error !== 0) return $error;
    $error = checkOneInFile($h);
    if ($error !== 0) return $error;
    $error = createOneTmpFile();
    if ($error !== 0) return $error;
    createOneConvFile();
    paraForConvImage();
    convImage();
    deleteOnetmpFile();
    return pushOneNewFile();
}

function OneLibreToOne($n, $h, $b) {
    $error = checkOneFromFile($n);
    if ($error !== 0) return $error;
    $error = checkOneInFile($h);
    if ($error !== 0) return $error;
    $error = createOneTmpFile();
    if ($error !== 0) return $error;
    createOneConvFile();
    paraForConvLibre();
    convLibre($b);
    deleteOnetmpFile();
    return pushOneNewFile();
}

global $typeconvert, $file, $filename, $fileout;
global $filenametmp, $execlog, $parametrs, $filenamelist, $filenewnametmp, $dirnewnametmp, $fileformat;

$dirnewnametmp = '/tmp/out';
# проверка наличия обязательных полей для этой команды
$req = api_check_request(["apikey","typeconvert","file","filename","fileout"]); if (!$req) return true;
list($apikey,$typeconvert,$file,$filename,$fileout) = $req;

# проверка корректности ключа
$userid = apikey_check($apikey); if (!$userid) return api_error(EFIELDBAD,"apikey");

# типы файлов. Стандартный: тип = array(форматы);
$image = array('png','jpeg','jpg','gif','bmp','tiff','tif','webp','avif','heif','heic','raw','jxl','svg','eps','pdf','ai','cdr','pbm');
$writer = array('odt','doc','docx','rtf','txt','html');
$calc = array('ods','xls','xlsx','csv');
$impress = array('odp','ppt','pptx');
$pdf = array('pdf');

# форматы, в которые можно сконвертироавть: тип конвертации => array(форматы)
$informats = [
    "ImageToImage"=>$image, "ImageToGif"=>array('gif'),
    "WriterToOdt"=>array('odt'), "WriterToDoc"=>array('doc'), "WriterToDocx"=>array('docx'), "WriterToRtf"=>array('rtf'), "WriterToHtml"=>array('html'),
    "CalcToOds"=>array('ods'), "CalcToXls"=>array('xls'), "CalcToXlsx"=>array('xlsx'), "CalcToCsv"=>array('csv'),
    "ImpressToOdp"=>array('odp'), "ImpressToPpt"=>array('ppt'), "ImpressToPptx"=>array('pptx'),
    "ImageToPdf"=>$pdf, "WriterToPdf"=>$pdf, "CalcToPdf"=>$pdf, "ImpressToPdf"=>$pdf
];

# фильтры для libreoffice: тип конвертации => фильтр
$librefilter = [
    "WriterToPdf"=>"writer_pdf_Export", "WriterToOdt"=>"writer8", "WriterToDoc"=>"MS Word 97",
    "WriterToDocx"=>"MS Word 2007 XML", "WriterToRtf"=>"Rich Text Format", "WriterToHtml"=>"HTML (StarWriter)",
    "CalcToOds"=>"calc8", "CalcToXls"=>"MS Excel 97", "CalcToXlsx"=>"Calc MS Excel 2007 XML",
    "CalcToCsv"=>"Text - txt - csv (StarCalc)", "CalcToPdf"=>"calc_pdf_Export",
    "ImpressToOdp"=>"impress8", "ImpressToPpt"=>"MS PowerPoint 97",
    "ImpressToPptx"=>"impress_ms_pptx_Export", "ImpressToPdf"=>"impress_pdf_Export"
];

# параметыры для конвертации
# для проверки входящих параметров. Стандартный: $<тип>paraname = array(название параметров);
# преоброзование входящих параметров для утилыт. Стандартный: $<тип>topara = ["название параметра" => "параметры для утилиты"]
global $imagetopara, $imageparaname, $librertopara, $libreparaname;
$imageparaname = array('resize','quality','rotate','blur','bordercolor','border','delay','loop');
$libreparaname = array('');

$imagetopara = [
    'resize'=>'-resize','quality'=>'-quality','rotate'=>'-rotate','blur'=>'-blur',
    'bordercolor'=>'-bordercolor','border'=>'-border','delay'=>'-delay','loop'=>'-loop'
];
$librertopara = [''=>''];

//return exitError("test",404);

switch ($typeconvert) {
    case 'ImageToImage':
        return OneImageToOne($image, $informats[$typeconvert]); break;
    case 'ImageToPdf': case 'ImageToGif':
        return SeveralImageToOne($image, $informats[$typeconvert]); break;
    case 'WriterToPdf': case 'WriterToOdt': case 'WriterToDoc': case 'WriterToDocx': case 'WriterToRtf': case 'WriterToHtml': 
        return OneLibreToOne($writer, $informats[$typeconvert], $librefilter[$typeconvert]); break;
    case 'CalcToOds': case 'CalcToXls': case 'CalcToXlsx': case 'CalcToCsv': case 'CalcToPdf':
        return OneLibreToOne($calc, $informats[$typeconvert], $librefilter[$typeconvert]); break;
    case 'ImpressToOdp': case 'ImpressToPpt': case 'ImpressToPptx': case 'ImpressToPdf':
        return OneLibreToOne($impress, $informats[$typeconvert], $librefilter[$typeconvert]);
    default: return exitError($typeconvert." нету такого правила конвертирования", 100);
}