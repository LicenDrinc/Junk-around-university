<?php

return api_json_result(index_gen());
